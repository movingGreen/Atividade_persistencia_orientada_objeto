package aplicacao;

import classes.Buraco;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

/**
 *
 * @author el_va
 */
public class Teste {
    public static void main(String[] args) {
        EntityManagerFactory factory = Persistence.createEntityManagerFactory("exemplo-jpa");
        EntityManager em = factory.createEntityManager();

        Buraco buraco_rua = new Buraco();
        buraco_rua.setRua("rua b");
        buraco_rua.setQuantidade("10");
//        buraco_rua.setDT("dezesseis de maio de mil novecentos e noventa e nove");;
        
        
        EntityTransaction tx = em.getTransaction();
        tx.begin();
        em.persist(buraco_rua);
        tx.commit();
        em.close();
        factory.close();
        
        System.out.println("Cadastrado com sucesso!");
    }

   
}